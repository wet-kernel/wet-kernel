
def k_distro ():
    process.show_start_process("distro")

    from etc import distro

    print("\n"+"Welcome to "+distro.name+" "+distro.version+"\n")

k_distro()