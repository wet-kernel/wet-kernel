
k_header_magic = "wet"
k_header_version = "0.23"
k_header_code = "test"
k_header_license = "GPL v3"