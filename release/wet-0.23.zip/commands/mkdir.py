def mkdir (values):
    if values[0]=="-p":
        for i in values[1:]:
            if os.path.isfile(root + "/" + i):
                print(process_colors.color(0,process_colors.red,process_colors.get_bgcolor())  + i + ": file exists." + process_colors.get_colors())
            elif os.path.isdir(root + "/" + i):
                print(process_colors.color(0,process_colors.yellow,process_colors.get_bgcolor()) + i + ": directory exists." + process_colors.get_colors())
            else:
                os.makedirs(root + "/" + i)
    else:
        for i in values:
            if os.path.isfile(root + "/" + i):
                print(process_colors.color(0,process_colors.red,process_colors.get_bgcolor())  + i + ": file exists." +process_colors.get_colors())
            elif os.path.isdir(root + "/" + i):
                print(process_colors.color(0,process_colors.yellow,process_colors.get_bgcolor()) + i + ": directory exists." + process_colors.get_colors())
            else:
                os.mkdir(root + "/" + i)