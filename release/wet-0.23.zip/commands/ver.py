def ver():
    from etc import distro
    distro = reload(distro)
    print ("\tDistro name:\t"+process_colors.color(1,process_colors.white,process_colors.get_bgcolor())+distro.name+" "+distro.version+process_colors.get_colors())
    print ("\tDistro version:\t"+process_colors.color(1,process_colors.white,process_colors.get_bgcolor())+distro.version_ID+process_colors.get_colors())
    print ("\tKernel name:\t"+process_colors.color(1,process_colors.white,process_colors.get_bgcolor())+k_header_magic+ " ("+k_header_code+")"+process_colors.get_colors())
    print ("\tKernel type:\t"+process_colors.color(1,process_colors.white,process_colors.get_bgcolor())+"Hight microkernel"+process_colors.get_colors())
    print ("\tKernel version:\t"+process_colors.color(1,process_colors.white,process_colors.get_bgcolor())+k_header_version+process_colors.get_colors())
    print ("\tLicense:\t"+process_colors.color(1,process_colors.white,process_colors.get_bgcolor())+k_header_license+process_colors.get_colors())