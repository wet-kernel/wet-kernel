
def shut():
    process.show_end_process("shell")
    process.show_power_off()
    exit(0)