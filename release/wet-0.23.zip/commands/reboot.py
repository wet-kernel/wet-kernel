def reboot():
    import vmwet
    vmwet = reload(vmwet)