#!/usr/bin/env bash

echo "Running wet kernel ..."
python3 vmwet.pyc

