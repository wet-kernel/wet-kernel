def ls (path):
    if os.path.isdir (root+"/"+path):
        dirs = os.listdir(root + "/" + path)
        for dir in dirs:
            if os.path.isfile(root + "/" + path + "/" + dir):
                print(dir + process_colors.get_colors())
            else:
                print(process_colors.color(1,process_colors.blue,process_colors.get_bgcolor()) + dir + "/" + process_colors.get_colors())
    else:
        print(process_colors.color(process_colors.get_style(),process_colors.red,process_colors.get_bgcolor())  +path+ ": directory not found." +process_colors.get_colors())