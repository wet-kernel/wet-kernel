def logout():
    k_clean()
    k_login()