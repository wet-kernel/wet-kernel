def mv (values):
    if os.path.isfile(root+"/"+values[0]):
        os.rename(root+"/"+values[0],root+"/"+values[1])
    else:
        print(process_colors.color(process_colors.get_style(),process_colors.red,process_colors.get_bgcolor())  + values[0] + ": source not found." + process_colors.get_colors())