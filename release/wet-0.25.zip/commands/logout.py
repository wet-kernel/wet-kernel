def logout():
    k_login()