
def k_issue():
    process.show_start_process("issue")

    print()
    show_issue()
    print()

k_issue()