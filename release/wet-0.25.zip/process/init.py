root = "."
path = "/"

def k_init():
    print (" \n")
    process.show_power_on()
    process.show_start_process("init")

k_init()